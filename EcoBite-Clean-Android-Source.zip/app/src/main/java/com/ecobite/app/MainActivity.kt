package com.ecobite.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val green = Color.rgb(30, 122, 82)
    private val dark = Color.rgb(28, 48, 39)
    private val muted = Color.rgb(105, 122, 112)
    private val pale = Color.rgb(239, 247, 241)
    private val cream = Color.rgb(250, 249, 245)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var savedCount = 0
    private var reservedCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showScreen("Discover")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int = dark, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(green, 24)
            setOnClickListener { action() }
        }

    private fun showScreen(screen: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cream)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        header.addView(text("EcoBite", 27f, green, true))
        header.addView(text("Good food. Less waste. Better tomorrow.", 13f, muted))
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(5), dp(9), dp(5), dp(9))
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        listOf("Discover", "Saved", "Impact", "Profile").forEach { item ->
            val b = TextView(this).apply {
                text = item
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (item == screen) green else muted)
                setTypeface(null, if (item == screen) Typeface.BOLD else Typeface.NORMAL)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener { showScreen(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)

        when (screen) {
            "Discover" -> discover()
            "Saved" -> saved()
            "Impact" -> impact()
            else -> profile()
        }
    }

    private fun sectionTitle(title: String, subtitle: String? = null) {
        content.addView(text(title, 22f, dark, true))
        if (subtitle != null) {
            val sub = text(subtitle, 13f, muted)
            sub.setPadding(0, dp(5), 0, dp(14))
            content.addView(sub)
        } else content.addView(space(12))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(Color.WHITE, 18)
    }

    private fun discover() {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(pale, 20)
        }
        hero.addView(text("Rescue a meal.\nMake a difference.", 24f, dark, true))
        hero.addView(text("Discover delicious surplus food near you and help local businesses waste less.", 14f, muted))
        hero.addView(space(12))
        hero.addView(text("DEMO LOCATION  •  Istanbul", 12f, green, true))
        content.addView(hero)
        content.addView(space(20))
        sectionTitle("Available near you", "Surplus food at a special price")
        foodCard("Fresh bakery box", "Green Oven Bakery", "₺85", "₺170", "Today · 18:00–20:00", "🥐")
        foodCard("Seasonal lunch bowl", "Daily Roots Kitchen", "₺110", "₺220", "Today · 14:00–16:00", "🥗")
        foodCard("Fruit rescue bag", "Market Garden", "₺55", "₺110", "Today · 19:00–21:00", "🍎")
        content.addView(space(12))
        content.addView(text("Demo prototype: offers are sample listings, not live restaurant inventory.", 11f, muted))
    }

    private fun foodCard(name: String, shop: String, price: String, old: String, time: String, emoji: String) {
        val card = panel()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val art = TextView(this).apply {
            text = emoji
            textSize = 30f
            gravity = Gravity.CENTER
            background = rounded(pale, 16)
        }
        row.addView(art, LinearLayout.LayoutParams(dp(66), dp(66)))
        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        details.addView(text(name, 17f, dark, true))
        details.addView(text(shop, 13f, muted))
        details.addView(text(time, 12f, muted))
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        val prices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        prices.addView(text(price, 17f, green, true))
        prices.addView(text(old, 12f, muted))
        row.addView(prices)
        card.addView(row)
        card.addView(space(12))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val reserve = button("Reserve") {
            reservedCount++
            Toast.makeText(this@MainActivity, "Demo reservation added!", Toast.LENGTH_SHORT).show()
        }
        actions.addView(reserve)
        val save = TextView(this).apply {
            text = "  ♡ Save"
            textSize = 14f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener {
                savedCount++
                Toast.makeText(this@MainActivity, "Saved to your list", Toast.LENGTH_SHORT).show()
            }
        }
        actions.addView(save)
        card.addView(actions)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12)
        content.addView(card, lp)
    }

    private fun saved() {
        sectionTitle("Your saved food", "Keep track of meals you want to rescue")
        val card = panel()
        card.addView(text("♡  Saved items: $savedCount", 18f, green, true))
        card.addView(space(8))
        card.addView(text("Tap Save on a food offer to add it to your saved list. This demo keeps a simple session count.", 14f, muted))
        content.addView(card)
        content.addView(space(14))
        content.addView(text("Reservations made in this session: $reservedCount", 14f, muted))
    }

    private fun impact() {
        sectionTitle("Your impact", "Small choices add up to meaningful change")
        metric("🥕", "Food rescued", "2.4 kg", "Illustrative demo impact")
        metric("🌍", "CO₂ avoided", "4.8 kg", "Estimated sample value")
        metric("💧", "Water saved", "1,200 L", "Illustrative sample estimate")
        content.addView(space(10))
        val card = panel()
        card.addView(text("Every rescued meal helps keep good food out of landfill and supports local food businesses.", 15f, dark))
        content.addView(card)
    }

    private fun metric(icon: String, label: String, value: String, note: String) {
        val card = panel()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(icon, 27f))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(text(label, 14f, muted))
        col.addView(text(value, 23f, green, true))
        col.addView(text(note, 11f, muted))
        row.addView(col)
        card.addView(row)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12)
        content.addView(card, lp)
    }

    private fun profile() {
        sectionTitle("Your EcoBite profile", "A simple preview of the customer experience")
        val card = panel()
        card.addView(text("Welcome, food rescuer!", 20f, dark, true))
        card.addView(space(8))
        card.addView(text("Account features such as sign-in, payment and restaurant verification are planned for a future connected version.", 14f, muted))
        content.addView(card)
        content.addView(space(14))
        content.addView(button("Explore food offers") { showScreen("Discover") })
        content.addView(space(18))
        content.addView(text("Version 1.0 · Competition prototype", 12f, muted))
    }
}
