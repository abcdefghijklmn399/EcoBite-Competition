# EcoBite Android prototype

A clean Android starter prototype for the EcoBite food-surplus marketplace.

## Current prototype features
- Sample surplus-food marketplace
- Demo reserve and save interactions
- Impact dashboard with illustrative sample metrics
- Customer profile preview
- Native Android app; no backend or live restaurant data yet

## Build
Requires JDK 17, Android SDK 35, and Gradle 8.9.
Run: `gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

This is a competition prototype, not a production marketplace. Reservations, accounts, payments, live inventory and impact calculations are demo-only.
